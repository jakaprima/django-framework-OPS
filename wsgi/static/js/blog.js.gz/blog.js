$('#btn-daftar').on('click', function(){
	$('.modal-background').css({'display':'block', 'transition': 'opacity .15s linear', 'background': 'rgba(0, 0, 0, 0.4)'})
})